#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct user {
	int id;
	long int ncode;
	int isadmin;
	long int money;
	int step;
	char fname[50];
	char lname[50];
	char username[50];
	char password[50];
};

struct stock{
	int id;
	long int code;
	char name[50];
	float value;
	long int amount;
};

struct set{
	int userid;
	int stockid;
	int shopid;
};

struct shop{
	int id;
	int userid;
	int stockid;
	long int amount;
	float value, sellvalue;
	int isactive;
};

void clrscr(){
	system("cls");
}

struct set getSet();
int setSet(struct set set);

int addUser(struct user User);
int deleteUser(int id);
int updateUser(struct user user);
struct user getUserById(int id);
struct user getUserByUsername(char username[50]);
struct user getUserByNcode(long int ncode);
struct user getUserByFamily(char family[50]);

void printUser(struct user User, int method);
void printAllUsers();

int addStock(struct stock Stock);
int deleteStock(int id);
struct stock getStockByCode(long int code);
struct stock getStockById(int id);
int updateStock(struct stock Stock);
void printStock(struct stock Stock, int method);
void printAllStocks();

int addShop(struct shop Shop);
int updateShop(struct shop Shop);
struct shop getShopById(int id);

void printUserByShop(int id);
void printShopByUser1(int userid);
void printShopByUser2(int id);

int main(){
	struct user u,newu;
	struct stock stock,newstock;
	struct shop shop;
	char username[50], password[50];
	int command=1;

	clrscr();
	// Get username
	printf("Hello!\nEnter Your username:");
	fflush(stdout);
	scanf("%s",username);
	u=getUserByUsername(username);
	while(u.id==-1){
		printf("User not found!\nEnter Your username:");
		fflush(stdout);
		scanf("%s",username);
		u=getUserByUsername(username);
	}

	clrscr();

	// Get password
	printf("Enter Your password:");
	fflush(stdout);
	scanf("%s",password);
	while(strcmp(password,u.password)!=0){
		printf("Invalid password!\nEnter your password (0 for logout):");
		fflush(stdout);
		scanf("%s",password);
		if(strcmp(password,"0")==0){
			main();
			return 0;
		}
	}

	clrscr();
	printf("Welcome...\nYou logged in as %s\n\n",(u.isadmin)?"admin":"user");
	u.step=0;

	FIRST:

	if(u.isadmin){

		if(u.step==0){
			ADMINMENU:
			printf("Manage users: 1\n"
					"Manage stocks: 2\n"
					"Logout: 3\n"
					"What do you wand to do? ");
			fflush(stdout);
			scanf("%d",&command);
			u.step=1;
			updateUser(u);
			goto FIRST;
		}

		else if(u.step==1 && command==3){
			main();
			return 0;
		}

		else if(u.step==1 && command==2){
			MANAGESTOCKS:
			if(u.id) u=getUserById(u.id);
			u.step=2;
			updateUser(u);
			clrscr();
			printf("Add new stock: 1\n"
					"Edit a stock: 2\n"
					"View all stocks: 3\n"
					"Back to main menu: 4\n"
					"What do you want to do? ");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==1 && command==1){
			MANAGEMEMBERS:
			if(u.id) u=getUserById(u.id);
			u.step=3;
			updateUser(u);
			clrscr();
			printf("Add new member: 1\n"
					"Search a member: 2\n"
					"View members list: 3\n"
					"View 10 top members: 4\n"
					"Search users by a special stock: 5\n"
					"Search stocks by a special member: 6\n"
					"Back to main menu: 7\n"
					"What do you want to do? ");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if((u.step==2 && command==4) || (u.step==3 && command==7)){
			clrscr();
			goto ADMINMENU;
			return 0;
		}

		else if(u.step==2 && command==1){
			ADDNEWSTOCK:
			clrscr();
			u.step=4;
			updateUser(u);
			printf("Enter the stock code (-1 to back menu):");
			fflush(stdout);
			scanf("%ld",&stock.code);
			if(stock.code==-1) goto MANAGESTOCKS;
			while(getStockByCode(stock.code).id!=-1){
				printf("This code exists!\n"
						"Enter another code (-1 to back menu):");
				fflush(stdout);
				scanf("%ld",&stock.code);
				if(stock.code==-1) goto MANAGESTOCKS;
			}

			printf("Enter the stock name:");
			fflush(stdout);
			scanf("%s",stock.name);

			printf("Enter the stock value:");
			fflush(stdout);
			scanf("%f",&stock.value);
			while(stock.value<0){
				printf("Value must be more than 0\n"
						"Enter the stock value:");
				fflush(stdout);
				scanf("%f",&stock.value);
			}

			printf("Enter the stock amount:");
			fflush(stdout);
			scanf("%ld",&stock.amount);
			while(stock.amount<0){
				printf("Amount must be more than 0\n"
						"Enter the stock amount:");
				fflush(stdout);
				scanf("%ld",&stock.amount);
			}
			addStock(stock);
			printf("\nNew stock successfully added!\n\n"
					"Add another new stock: 1\n"
					"Back to main menu: 2\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==4 && command==2){
			clrscr();
			goto ADMINMENU;
		}

		else if(u.step==4 && command==1){
			goto ADDNEWSTOCK;
		}

		else if(u.step==2 && command==2){
			u.step=5;
			updateUser(u);
			clrscr();
			printf("Enter the stock code (-1 to back menu):");
			fflush(stdout);
			scanf("%ld",&stock.code);
			if(stock.code==-1) goto MANAGESTOCKS;
			while(getStockByCode(stock.code).id==-1){
				printf("Stock not found!\n"
						"Enter the stock code (-1 to back menu):");
				fflush(stdout);
				scanf("%ld",&stock.code);
				if(stock.code==-1) goto MANAGESTOCKS;
			}
			stock=getStockByCode(stock.code);
			EDITSTOCK:
			printStock(stock,3);
			printf("\n\nEdit value: 1\n"
					"Edit amount: 2\n"
					"Go to back menu: 3\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==5 && command==3){
			clrscr();
			goto MANAGESTOCKS;
		}

		else if(u.step==5 && command==2){
			printf("\nEnter new amount:");
			fflush(stdout);
			scanf("%ld",&stock.amount);
			while(stock.amount<0){
				printf("Amount must be more than 0\n"
						"Enter the stock amount:");
				fflush(stdout);
				scanf("%ld",&stock.amount);
			}
			updateStock(stock);
			clrscr();
			printf("Stock amount updated!\n");
			goto EDITSTOCK;
		}

		else if(u.step==5 && command==1){
			printf("\nEnter new value:");
			fflush(stdout);
			scanf("%f",&stock.value);
			while(stock.value<0){
				printf("Value must be more than 0\n"
						"Enter the stock value:");
				fflush(stdout);
				scanf("%f",&stock.value);
			}
			updateStock(stock);
			clrscr();
			printf("Stock amount updated!\n");
			goto EDITSTOCK;
		}

		else if(u.step==2 && command==3){
			clrscr();
			printAllStocks();
			printf("\n\nAdd new stock: 1\n"
					"Edit a stock: 2\n"
					"View all stocks: 3\n"
					"Back to main menu: 4\n"
					"What do you want to do? ");
			scanf("%d",&command);
			u.step=2;
			updateUser(u);
			goto FIRST;
		}

		else if(u.step==3 && command==1){
			ADDNEWMEMBER:
			clrscr();
			u.step=6;
			updateUser(u);
			printf("Enter the new member first name (-1 to back menu):");
			fflush(stdout);
			scanf("%s",newu.fname);
			if(strcmp(newu.fname,"-1")==0) goto MANAGEMEMBERS;

			printf("Enter the new member last name (-1 to back menu):");
			fflush(stdout);
			scanf("%s",newu.lname);
			if(strcmp(newu.lname,"-1")==0) goto MANAGEMEMBERS;

			printf("Enter the new member username (-1 to back menu):");
			fflush(stdout);
			scanf("%s",newu.username);
			while(getUserByUsername(newu.username).id!=-1){
				printf("This username exists!\n"
						"Enter the new member username (-1 to back menu):");
				fflush(stdout);
				scanf("%s",newu.username);
			}
			if(strcmp(newu.username,"-1")==0) goto MANAGEMEMBERS;

			printf("Enter the new member password (-1 to back menu):");
			fflush(stdout);
			scanf("%s",newu.password);
			if(strcmp(newu.password,"-1")==0) goto MANAGEMEMBERS;

			printf("Enter the new member nation code (-1 to back menu):");
			fflush(stdout);
			scanf("%ld",&newu.ncode);
			while(getUserByNcode(newu.ncode).id!=-1){
					printf("This nation code exists!\n"
							"Enter the new member username (-1 to back menu):");
					fflush(stdout);
					scanf("%ld",&newu.ncode);
				}
			while(newu.ncode<0){
				printf("Nation code must be larger than 0!\n"
						"Enter the new member username (-1 to back menu):");
				fflush(stdout);
				scanf("%ld",&newu.ncode);
			}
			if(newu.ncode==-1) goto MANAGEMEMBERS;

			printf("Is this member a user or an admin?\n"
					"(0 for member, 1 for admin):");
			fflush(stdout);
			scanf("%d",&newu.isadmin);
			while(newu.isadmin != 0 && newu.isadmin != 1){
				printf("Enter 1 or 0!\n"
						"(0 for member, 1 for admin):");
				fflush(stdout);
				scanf("%d",&newu.isadmin);
			}

			if(newu.isadmin){
				newu.money=0;
			}
			else{
				printf("Enter the new member money (-1 to back menu):");
				fflush(stdout);
				scanf("%ld",&newu.money);
				if(newu.money==-1) goto MANAGEMEMBERS;
				while(newu.money<0){
					printf("Member money must be larger than or equal to 0\n"
							"Enter the new member money (-1 to back menu):");
					fflush(stdout);
					scanf("%ld",&newu.money);
				}
			}
			addUser(newu);

			printf("\nNew member successfully added!\n\n"
					"Add another new member: 1\n"
					"Back to main menu: 2\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==6 && command==1){
			goto ADDNEWMEMBER;
		}

		else if(u.step==6 && command==2){
			clrscr();
			goto ADMINMENU;
		}

		else if(u.step==3 && command==2){
			SEARCHMEMBERS:
			u.step=7;
			updateUser(u);
			clrscr();
			printf("Search by family: 1\n"
					"Search by nation code: 2\n"
					"Back to previous menu: 3\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==7 && command==3){
			goto MANAGEMEMBERS;
		}

		else if(u.step==7 && command==1){
			SEARCHBYFAMILY:
			clrscr();
			u.step=8;
			updateUser(u);
			printf("Enter family (-1 to back): ");
			fflush(stdout);
			scanf("%s",newu.lname);
			if(strcmp(newu.lname,"-1")==0) goto SEARCHMEMBERS;
			while(getUserByFamily(newu.lname).id==-1){
				printf("\nUser not found\n"
						"Enter family (-1 to back): ");
				fflush(stdout);
				scanf("%s",newu.lname);
				if(strcmp(newu.lname,"-1")==0) goto SEARCHMEMBERS;
			}
			newu=getUserByFamily(newu.lname);
			printUser(newu,3);

			printf("\n\nSearch another user: 1\n"
					"Back to previous menu: 2\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==8 && command==1){
			goto SEARCHBYFAMILY;
		}

		else if(u.step==8 && command==2){
			goto SEARCHMEMBERS;
		}

		else if(u.step==7 && command==2){
			SEARCHBYNATIONCODE:
			clrscr();
			u.step=9;
			updateUser(u);
			printf("Enter nation code (-1 to back): ");
			fflush(stdout);
			scanf("%ld",&newu.ncode);
			if(newu.ncode==-1) goto SEARCHMEMBERS;
			while(getUserByNcode(newu.ncode).id==-1){
				printf("\nUser not found\n"
						"Enter nation code (-1 to back): ");
				fflush(stdout);
				scanf("%ld",&newu.ncode);
				if(newu.ncode==-1) goto SEARCHMEMBERS;
			}
			newu=getUserByNcode(newu.ncode);
			printUser(newu,3);

			printf("\n\nSearch another user: 1\n"
					"Back to previous menu: 2\n"
					"What do you want to do? ");
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==9 && command==1){
			goto SEARCHBYNATIONCODE;
		}

		else if(u.step==9 && command==2){
			goto SEARCHMEMBERS;
		}

		else if(u.step==3 && command==3){
			clrscr();
			u.step=10;
			updateUser(u);
			printAllUsers();
			printf("\n\nEnter 0 to go to previous menu: ");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==10 && command==0){
			goto MANAGEMEMBERS;
		}

		else if(u.step==3 && command==5){
			u.step==11;
			updateUser(u);
			clrscr();
			printf("Enter stock code(-1 to back) :");
			scanf("%ld",&stock.code);
			if(stock.code==-1) goto MANAGEMEMBERS;
			while(getStockByCode(stock.code).id==-1){
				printf("\nStock not found!\n"
				"Enter stock code(-1 to back) :");
				scanf("%ld",&stock.code);
			if(stock.code==-1) goto MANAGEMEMBERS;
			}
			stock=getStockByCode(stock.code);
			puts("\n");
			printUserByShop(stock.id);
			printf("\nEnter 0 to go back menu:");
			scanf("%d",&command);
			goto FIRST;
		}
		
		else if(u.step==11 && command==0){
			clrscr();
			goto MANAGEMEMBERS;
		}
		
		else if(u.step==3 && command==6){
			u.step==12;
			updateUser(u);
			clrscr();
			printf("Enter user nation code(-1 to back) :");
			scanf("%ld",&newu.ncode);
			if(newu.ncode==-1) goto MANAGEMEMBERS;
			while(getUserByNcode(newu.ncode).id==-1){
				printf("\nUser not found!\n"
				"Enter user nation code(-1 to back) :");
				scanf("%ld",&newu.ncode);
			if(newu.ncode==-1) goto MANAGEMEMBERS;
			}
			newu=getUserByNcode(newu.ncode);
			puts("\n");
			printShopByUser2(stock.id);
			printf("\nEnter 0 to go back menu:");
			scanf("%d",&command);
			goto FIRST;
		}
		
		else if(u.step==11 && command==0){
			clrscr();
			goto MANAGEMEMBERS;
		}

	}

	else{

		if(u.step==0){
			MEMBERMENU:
			printf("My status: 1\n"
					"Stocks: 2\n"
					"Logout: 3\n"
					"What do you wand to do? ");
			fflush(stdout);
			scanf("%d",&command);
			u.step=1;
			updateUser(u);
			goto FIRST;
		}

		else if(u.step==1 && command==3){
			main();
			return 0;
		}

		else if(u.step==1 && command==1){

		}

		else if(u.step==1 && command==2){
			MEMBERSTOCK:
			u.step=2;
			updateUser(u);
			clrscr();
			printf("Buy stock: 1\n"
					"Sell stock: 2\n"
					"View recent new stocks: 3\n"
					"Search a stock: 4\n"
					"My stocks: 5\n"
					"Back to main menu: 6\n"
					"What do you want to do? ");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==2 && command==6){
			clrscr();
			goto MEMBERMENU;
		}

		else if(u.step==2 && command==1){
			BUYSTOCK:
			u.step=3;
			updateUser(u);
			clrscr();
			printf("Enter the stock code (-1 to back):");
			fflush(stdout);
			scanf("%ld",&stock.code);
			if(stock.code==-1) goto MEMBERSTOCK;
			while(getStockByCode(stock.code).id==-1){
				printf("\nStock not found!\n"
						"Enter the stock code (-1 to back):");
				fflush(stdout);
				scanf("%ld",&stock.code);
				if(stock.code==-1) goto MEMBERSTOCK;
			}
			stock=getStockByCode(stock.code);
			printStock(stock,3);
			u=getUserByUsername(username);
			int max;
			max=u.money/(int) stock.value;
			if(max>stock.amount) max=stock.amount;
			printf("\n\nYour money=%ld \n"
					"How many \"%s\" do you want to buy (0 to cancel and max=%d)? ",
					u.money,stock.name,(int) max);
			fflush(stdout);
			scanf("%d",&command);
			while(command>max || command<0){
				printf("You should enter a possitive value!\n"
						"Also it must be loewr than %d\n"
						"Enter again (enter 0 to cancel):",(int) max);
				fflush(stdout);
				scanf("%d",&command);
			}
			if(command==0) goto BUYSTOCK;
			shop.amount=command;
			shop.userid=u.id;
			shop.stockid=stock.id;
			shop.value=stock.value;
			addShop(shop);
			u.money-=(int) command*stock.value;
			stock.amount-=command;
			updateUser(u);
			updateStock(stock);
			printf("\nYou successfully bought %ld stocks of \"%s\"\n"
					"Your money: %ld\n\n"
					"Buy another stock: 1\n"
					"Go to back menu: 2\n"
					"What do you want to do? ",shop.amount,stock.name,u.money);
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==3 && command==1){
			goto BUYSTOCK;
		}

		else if(u.step==3 && command==2){
			goto MEMBERSTOCK;
		}

		else if(u.step==2 && command==2){
			SELLSTOCK:
			u.step=4;
			updateUser(u);
			clrscr();
			printShopByUser1(u.id);
			printf("\n\nEnter Payment ID to sell it (-1 to back):");
			fflush(stdout);
			scanf("%d",&shop.id);
			if(shop.id==-1) goto MEMBERSTOCK;
			shop=getShopById(shop.id);
			while(shop.userid==-1 || shop.userid != u.id || !shop.isactive){
				printf("\nPayment not found!\n"
						"Enter the Payment ID (-1 to back):");
				fflush(stdout);
				scanf("%d",&shop.id);
				shop=getShopById(shop.id);
				if(shop.id==-1) goto MEMBERSTOCK;
			}
			newstock=getStockById(shop.stockid);
			printf("\n\n%d",newstock.id);
			shop.isactive=0;
			shop.sellvalue=newstock.value;
			u.money+=shop.amount*(int) newstock.value;
			newstock.amount+=shop.amount;
			updateUser(u);
			updateStock(newstock);
			updateShop(shop);
			printf("\nYou successfully selled %ld stocks of \"%s\"\n"
					"Your money: %ld\n\n"
					"Sell another stock: 1\n"
					"Go to back menu: 2\n"
					"What do you want to do? ",shop.amount,newstock.name,u.money);
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==4 && command==1){
			goto SELLSTOCK;
		}

		else if(u.step==4 && command==2){
			goto MEMBERSTOCK;
		}

		else if(u.step==2 && command==4){
			SEARCHSTOCKBYMEMBER:
			clrscr();
			u.step=5;
			updateUser(u);
			printf("Enter the stock code (-1 to back):");
			fflush(stdout);
			scanf("%ld",&stock.code);
			if(stock.code==-1) goto MEMBERSTOCK;
			while(getStockByCode(stock.code).id==-1){
				printf("\nStock not found!\n"
						"Enter the stock code (-1 to back):");
				fflush(stdout);
				scanf("%ld",&stock.code);
				if(stock.code==-1) goto MEMBERSTOCK;
			}
			stock=getStockByCode(stock.code);
			printStock(stock,3);
			printf("\n\nSearch another stock: 1\n"
					"Go back menu: 2\n"
					"What do you want to do? ");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==5 && command==1){
			goto SEARCHSTOCKBYMEMBER;
		}

		else if(u.step==5 && command==2){
			goto MEMBERSTOCK;
		}

		else if(u.step==2 && command==5){
			clrscr();
			u.step=6;
			updateUser(u);
			printShopByUser1(u.id);
			printf("\n\nEnter 0 to back:");
			fflush(stdout);
			scanf("%d",&command);
			goto FIRST;
		}

		else if(u.step==6 && command==0){
			goto MEMBERSTOCK;
		}




	}



main();

	return 0;
}

struct set getSet(){
	FILE *setfile;
	struct set set;
	setfile=fopen("set.txt","rt");
	fscanf(setfile,"%d %d %d",&set.userid,&set.stockid,&set.shopid);
	fclose(setfile);
	return set;
}

int setSet(struct set set){
	FILE *setfile;
	setfile=fopen("set.txt","wt");
	fprintf(setfile,"%d %d %d",set.userid,set.stockid,set.shopid);
	fclose(setfile);
	return 1;
}

int addUser(struct user User){
	FILE *file;
	struct set set=getSet();
	file=fopen("users.txt","at");
	fprintf(file,"%d %s %s %s %s %ld %d %ld %d\n",
	set.userid,User.username,User.password,User.fname,User.lname,User.ncode,User.isadmin,User.money,0);
	fclose(file);
	set.userid++;
	setSet(set);
	return 1;
}

int deleteUser(int id){
	FILE *file,*File;
	struct user User;
	file=fopen("users.txt","rt");
	File=fopen("tmp.txt","wt");
	while(!feof(file)){
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d\n",
					&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(id!=User.id)
			fprintf(File,"%d %s %s %s %s %ld %d %ld %d\n",
			User.id,User.username,User.password,User.fname,User.lname,User.ncode,User.isadmin,User.money,User.step);
	}
	fclose(File);
	fclose(file);
	unlink("users.txt");
	rename("tmp.txt","users.txt");
	return 1;
}

int updateUser(struct user user){
	FILE *file,*File;
	struct user User;
	file=fopen("users.txt","rt");
	File=fopen("tmp.txt","wt");
	while(!feof(file)){
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d\n",
					&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(user.id==User.id)
			User=user;
		fprintf(File,"%d %s %s %s %s %ld %d %ld %d\n",
			User.id,User.username,User.password,User.fname,User.lname,User.ncode,User.isadmin,User.money,User.step);
	}
	fclose(File);
	fclose(file);
	unlink("users.txt");
	rename("tmp.txt","users.txt");
	return 1;
}

struct user getUserById(int id){
	struct user User;
	FILE *file;
	int check=0;
	file=fopen("users.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d\n",
					&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(User.id==id){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) User.id=-1;
	fclose(file);
	return User;
}

struct user getUserByUsername(char username[50]){
	FILE *file;
	struct user User;
	int check=0;
	file=fopen("users.txt","rt");
	if(!file) puts("Error loading users.txt!");
	do{
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d",
				&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(strcmp(User.username,username)==0){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) User.id=-1;
	fclose(file);
	return User;
}

struct user getUserByNcode(long int ncode){
	struct user User;
	FILE *file;
	int check=0;
	file=fopen("users.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d\n",
					&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(User.ncode==ncode){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) User.id=-1;
	fclose(file);
	return User;
}

struct user getUserByFamily(char family[50]){
	FILE *file;
	struct user User;
	int check=0;
	file=fopen("users.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d",
				&User.id,User.username,User.password,User.fname,User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		if(strcmp(User.lname,family)==0){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) User.id=-1;
	fclose(file);
	return User;
}

void printUser(struct user User,int method){
	if(method==1)
		printf("\nFirst name     Last name     username    password   Nation code     money\n");
	else if(method==2)
		printf("\n%10s%14s%13s%12s%14ld%10ld",User.fname,User.lname,User.username,
				User.password,User.ncode,User.money);
	else
	printf("\nFirst name     Last name     username    password   Nation code     money\n"
			"%10s%14s%13s%12s%14ld%10ld",User.fname,User.lname,User.username,
			User.password,User.ncode,User.money);
}

void printAllUsers(){
	FILE *file;
	struct user User;
	file=fopen("users.txt","rt");
	printUser(User,1);
	while(!feof(file)){
		fscanf(file,"%d %s %s %s %s %ld %d %ld %d\n",
					&User.id,User.username,User.password,User.fname,
					User.lname,&User.ncode,&User.isadmin,&User.money,&User.step);
		printUser(User,2);
	}
	fclose(file);
}

int addStock(struct stock Stock){
	FILE *file;
	struct set set=getSet();
	file=fopen("stock.txt","at");
	fprintf(file,"%d %ld %s %f %ld\n",
	set.stockid,Stock.code,Stock.name,Stock.value,Stock.amount);
	fclose(file);
	set.stockid++;
	setSet(set);
	return 1;
}

int deleteStock(int id){
	FILE *file,*File;
	struct stock Stock;
	file=fopen("stock.txt","rt");
	File=fopen("tmp.txt","wt");
	while(!feof(file)){
		fscanf(file,"%d %ld %s %f %ld\n",
					&Stock.id,&Stock.code,Stock.name,&Stock.value,&Stock.amount);
		if(id!=Stock.id)
			fprintf(File,"%d %ld %s %f %ld\n",
				Stock.id,Stock.code,Stock.name,Stock.value,Stock.amount);
	}
	fclose(File);
	fclose(file);
	unlink("stock.txt");
	rename("tmp.txt","stock.txt");
	return 1;
}

struct stock getStockByCode(long int code){
	struct stock Stock;
	FILE *file;
	int check=0;
	file=fopen("stock.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %ld %s %f %ld\n",
				&Stock.id,&Stock.code,Stock.name,&Stock.value,&Stock.amount);
		if(Stock.code==code){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) Stock.id=-1;
	fclose(file);
	return Stock;
}

struct stock getStockById(int id){
	struct stock Stock;
	FILE *file;
	int check=0;
	file=fopen("stock.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %ld %s %f %ld\n",
				&Stock.id,&Stock.code,Stock.name,&Stock.value,&Stock.amount);
		if(Stock.id==id){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) Stock.id=-1;
	fclose(file);
	return Stock;
}

int updateStock(struct stock stock){
	FILE *file,*File;
	struct stock Stock;
	file=fopen("stock.txt","rt");
	File=fopen("tmp.txt","wt");
	while(!feof(file)){
		fscanf(file,"%d %ld %s %f %ld\n",
					&Stock.id,&Stock.code,Stock.name,&Stock.value,&Stock.amount);
		if(stock.id==Stock.id)
			Stock=stock;
		fprintf(File,"%d %ld %s %f %ld\n",
						Stock.id,Stock.code,Stock.name,Stock.value,Stock.amount);

	}
	fclose(File);
	fclose(file);
	unlink("stock.txt");
	rename("tmp.txt","stock.txt");
	return 1;
}

void printStock(struct stock Stock,int method){
	if(method==1)
		printf("\nStock code        Stock name    Stock value    Stock amount\n");
	else if(method==2)
		printf("\n%10ld%18s%15.0f%16ld",Stock.code,Stock.name,Stock.value,Stock.amount);
	else
	printf("\nStock code        Stock name    Stock value    Stock amount\n"
			"%10ld%18s%15.0f%16ld",Stock.code,Stock.name,Stock.value,Stock.amount);
}

void printAllStocks(){
	FILE *file;
	struct stock Stock;
	printStock(Stock,1);
	file=fopen("stock.txt","rt");
	while(!feof(file)){
		fscanf(file,"%d %ld %s %f %ld\n",
					&Stock.id,&Stock.code,Stock.name,&Stock.value,&Stock.amount);
			printStock(Stock,2);
	}
	fclose(file);
}

int addShop(struct shop Shop){
	FILE *file;
	struct set set=getSet();
	file=fopen("shop.txt","at");
	fprintf(file,"%d %d %d %ld %f %f %d\n",
	set.shopid,Shop.userid,Shop.stockid,Shop.amount,Shop.value,0.0,1);
	fclose(file);
	set.shopid++;
	setSet(set);
	return 1;
}

int updateShop(struct shop Shop){
	FILE *file,*File;
	struct shop shop;
	file=fopen("shop.txt","rt");
	File=fopen("tmp.txt","wt");
	while(!feof(file)){
		fscanf(file,"%d %d %d %ld %f %f %d\n",
							&Shop.id,&Shop.userid,&Shop.stockid,&Shop.amount,&Shop.value,&Shop.sellvalue,&Shop.isactive);
		if(shop.id==Shop.id)
			shop=Shop;
		fprintf(file,"%d %d %d %ld %f %f %d\n",
			shop.id,shop.userid,shop.stockid,shop.amount,shop.value,shop.sellvalue,shop.isactive);
	}
	fclose(File);
	fclose(file);
	unlink("stock.txt");
	rename("tmp.txt","stock.txt");
	return 1;
}

struct shop getShopById(int id){
	struct shop Shop;
	FILE *file;
	int check=0;
	file=fopen("shop.txt","rt");
	if(!file) puts("Error!");
	do{
		fscanf(file,"%d %d %d %ld %f %f %d\n",
					&Shop.id,&Shop.userid,&Shop.stockid,&Shop.amount,&Shop.value,&Shop.sellvalue,&Shop.isactive);
		if(Shop.id==id){
			check=1;
			break;
		}
	}while(!feof(file));
	if(!check) Shop.userid=-1;
	fclose(file);
	return Shop;
}

void printUserByShop(int id){
	struct shop shop;
	struct user user;
	FILE *file;
	file=fopen("shop.txt","rt");
	if(!file) puts("Error!");
	printf("First name    Last name    Nation code     Amount   Value\n");
	while(!feof(file)){
		fscanf(file,"%d %d %d %ld %f %f %d\n",
				&shop.id,&shop.userid,&shop.stockid,&shop.amount,&shop.value,&shop.sellvalue,&shop.isactive);
		if(shop.stockid=id){
			user=getUserById(shop.userid);
			printf("%10s%13s%15ld%11d%7.0f\n",user.fname,user.lname,user.ncode,shop.amount,shop.value);
		}
	}
	fclose(file);
}

void printShopByUser1(int userid){
	struct shop Shop;
	struct stock Stock;
	long int profit;
	FILE *file;
	file=fopen("shop.txt","rt");
	if(!file) puts("Error!");
	printf("Pay ID    Stock name   Stock code   Amount  Init value  Cur value    Profit\n");
	do{
		fscanf(file,"%d %d %d %ld %f %f %d\n",
					&Shop.id,&Shop.userid,&Shop.stockid,&Shop.amount,&Shop.value,&Shop.sellvalue,&Shop.isactive);
		if(userid==Shop.userid && Shop.isactive){
			Stock=getStockById(Shop.id);
			profit=Shop.amount*((int) Stock.value - (int) Shop.value);
			printf("%6d%14s%13ld%9ld%12.0f%11.0f%10ld\n",
					Shop.id, Stock.name, Stock.code, Shop.amount, Shop.value, Stock.value, profit);
		}
	}while(!feof(file));
	fclose(file);
}

void printShopByUser2(int userid){
	struct shop Shop;
	struct stock Stock;
	FILE *file;
	file=fopen("shop.txt","rt");
	if(!file) puts("Error!");
	printf("Stock name   Stock code     Amount\n");
	do{
		fscanf(file,"%d %d %d %ld %f %f %d\n",
					&Shop.id,&Shop.userid,&Shop.stockid,&Shop.amount,&Shop.value,&Shop.sellvalue,&Shop.isactive);
		if(userid==Shop.userid){
			Stock=getStockById(Shop.id);
			printf("%10s%13ld%11ld\n",
					Stock.name, Stock.code, Shop.amount);
		}
	}while(!feof(file));
	fclose(file);
}
